module.exports = (bot) => {
	bot.status({
		text: "PR!help",
		type: "LISTENING", 
		status: "online", 
		time: 6
	}) 
}