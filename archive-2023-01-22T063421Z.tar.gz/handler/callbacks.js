module.exports = (bot) => {
	bot.onMessage();
	bot.onInteractionCreate();
}