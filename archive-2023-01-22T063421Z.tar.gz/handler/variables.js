module.exports = (bot) => {
  bot.variables({
    //important
    prefix: "PR!",
    //color
    color: "1398ff",
    //economy
    sending:"0",
    notif:"",
    cash:"0",
    casino:"unset",
    bank:"0",
    dstreak: "1",
    lootbox: "0",
    created: "",
    //emojis
    symbol: "<:prime_coin:1066331809387913327>",
    check: "<:icon_tick:1064960249326481508>",
    tick: "<:icon_tick:1064960249326481508>",
    error: "<:icon_error:1062085589962330152>",
    shine: "<:icon_shine:1065500076308447266>",
    menu: "<:Icon_Menu:1065505072370430024>",
    })
}