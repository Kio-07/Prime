module.exports = {
	Bot: {
		token: "MTA2NDYwNjI2OTg0NTAyODk1NA.GIBL2P.oEccg-PRbnslf6PUZF69CZBIBJr6G0r41EeD8Q",
		prefix: ["$getServerVar[prefix]","<@$clientid>"],
		intents: "all",
    database: {
      db: require("aoi.db"),
      type: "aoi.db",
      path: "./database/",
      tables: ["main"],
      extraOptions: {
        dbType: "KeyValue"
      }
    }
  }
}