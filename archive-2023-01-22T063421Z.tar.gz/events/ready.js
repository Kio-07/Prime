module.exports = (bot) => {
	bot.readyCommand({
		channel: "", 
		code: `$log[Bot is online.]`
	})
}