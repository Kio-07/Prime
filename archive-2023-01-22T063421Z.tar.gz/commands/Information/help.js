module.exports = [{
    name: "help",
    code: `
$author[Thank you for choosing Prime;$authoravatar]
$description[> • Prefix: $getservervar[prefix]
> • Total commands: $commandscount
> • Developer: [Kio](https://discord.com/users/$botownerid)
> • Type \`$getservervar[prefix]help < command | module >\` for more information on a command or category.

**Please choose an option below to see more commands.**
> • **Main**: \`1 category \`]
$color[$getvar[color]]
$image[https://media.discordapp.net/attachments/1061186510545748028/1066377993829748807/standard_1.gif]
$addSelectMenu[1;menu;Select a categories for more information;1;1;no;Main:View all commands inside Main category:main:no:<:Icon_Menu:1065505072370430024>;Extras:View all commands inside Extra category:extra:no:<:icons_settings:1062595086514405426>]
`
}]