module.exports = {
name: "removemoney",
aliases: "removebal",
usage: "removemoney < amount > < userID >",
code: `
$description[$getServerVar[check] **| Removed $numberSeparator[$get[amount];,] $getServerVar[symbol] from <@$get[u]>**]
$color[$getvar[color]]
$setUserVar[cash;$sub[$getUserVar[cash;$get[u]];$get[amount]];$get[u]]

$onlyIf[$isNumber[$get[amount]]!=false;{newEmbed:{description:$getServerVar[error] **| You provided an invalid number**}
{color:$getvar[color]}}]

$onlyIf[$checkContains[$get[amount];-;+;=;_;.;,;/]==false;{newEmbed:
{description:$getServerVar[error] **| You provided an invalid number**}
{color:$getvar[color]}}]

$argsCheck[>0;{newEmbed:
{discription:
\`\`\`
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`

**Usage**
\`$getServerVar[prefix]removemoney < user > < amount >\`}
{color:$getvar[color]}}]

$let[amount;$truncate[$message[2]]]
$let[u;$findMember[$message[1];yes]]
$suppressErrors[wrong usage]
$onlyforids[$botownerid;You do not own this bot.]`}