module.exports = {
name: "addmoney",
aliases: "addsmoney",
usage: "addmoney < userID > < amount >",
code: `
$description[$getServerVar[check] **| Added $numberSeparator[$get[amount];,]$getServerVar[symbol] to <@$get[u]>**]
$color[$getvar[color]
$setUserVar[cash;$sum[$getUserVar[cash;$get[u]];$get[amount]];$get[u]]

$onlyIf[$isNumber[$get[amount]]!=false;{newEmbed:{description:$getServerVar[error] **| You provided an invalid number**}
{color:$getvar[color]}]
$onlyIf[$checkContains[$get[amount];-;+;=;_;.;,;/]==false;{newEmbed:{description:$getServerVar[error] **| You provided an invalid number**}
{color:$getvar[color]}]

$argsCheck[>0;{newEmbed:
{discription:
\`\`\`
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`

**Usage**
\`$getServerVar[prefix]addmoney < user > < amount >\`}
{color:$getvar[color]}}]

$let[amount;$truncate[$message[2]]]
$let[u;$findMember[$message[1];yes]]
$suppressErrors[wrong usage]
$onlyForIds[$botownerid;You do not own this bot.]`}