module.exports = {
name: "balance",
aliases: ['bal','wallet','cash'],
usage: "balance < userID >",
code: `
$author[1;$userTag[$get[u]];$useravatar[$get[u]]]
$color[1;$getServerVar[color]]
$description[1;**<a:cashfly:1061716901471981728> Wallet - $numberSeparator[$getUserVar[cash;$get[u]];,] $getServerVar[symbol]**]
$onlyIf[$getUserVar[casino;$get[u]]!=unset;{newEmbed:{description:$getServerVar[error] **| You / They dont have a casino**}
{color:$getvar[color]}}]
$let[u;$findUser[$message;yes]]
$cooldown[5s;$getServerVar[error] **$username** You are **still** on cooldown, \`%time%\` left]`}