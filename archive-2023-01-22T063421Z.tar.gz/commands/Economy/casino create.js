module.exports = {
    name: "casino create",
    code: `
$description[$getServerVar[check] **|  $username Your Casino has been created.**]
$color[$getVar[color]]
$setUserVar[casino;set]
$setglobaluservar[created;$formatDate[$datestamp;LLLL]$timezone[Asia/Kolkata]]
$onlyIf[$getUserVar[casino]==unset;{newEmbed:
{description:$getServerVar[error] **| $username You already own a casino.**}
{color:$getvar[color]}
}]
`
}