module.exports = {
name: "addall",
aliases: "addeveryone",
usage: "addall < amount >",
code:`$forEachMember[1;{};egivemoney;]
$description[$getServerVar[check] **| Added $numberSeparator[$message[1];,] $getServerVar[symbol] to all members**]
$color[$getvar[color]]

$setServerVar[sending;$message[1]]

$onlyif[$isnumber[$message[1]]==true;{newEmbed:
{description:$getServerVar[error] **| $username You provided an invalid number**}
{color:$getvar[color]}}]

$argsCheck[1;{newEmbed:
{discription:
\`\`\`
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`

**Usage**
\`$getServerVar[prefix]addall < amount >\`}
{color:$getvar[color]}}]

$onlyForIds[$botownerid;You do not own this bot.]
`}