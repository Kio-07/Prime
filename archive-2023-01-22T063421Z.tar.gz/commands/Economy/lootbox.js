module.exports = {
name: "lootbox",
aliases: "lb",
usage: "lootbox < amount >",
code: `
$description[$getServerVar[check] **| $username You opened $numberSeparator[$message;,] 🎁 and got $numberSeparator[$multi[$random[100;500];$message];,] $getServerVar[symbol]**]
$color[$getvar[color]]

$setUserVar[cash;$sum[$getUserVar[cash];$multi[$random[100;500];$message]]]

$setUserVar[lootbox;$sub[$getUserVar[lootbox];$message]]

$cooldown[10s;{newEmbed:
{discription:
$getServerVar[error] **| $username You are **still** on cooldown,** \`%time%\` left}
{color:$getvar[color]}}]

$onlyIf[$getUserVar[lootbox]>=$multi[1;$message];{newEmbed:
{discription:$getServerVar[error] **| $username You don't have that many lootboxes**}
{color:$getvar[color]}}]

$onlyIf[$message!=;{newEmbed:
{discription:
\`\`\`
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`

**Usage**
\`$getServerVar[prefix]lootbox < amount >\`}
{color:$getvar[color]}}]

$onlyIf[$getUserVar[casino]!=unset;{newEmbed:
{description:
$getServerVar[error] **| $username You don't have a casino.**}
{color:$getVar[color]}}]
`}