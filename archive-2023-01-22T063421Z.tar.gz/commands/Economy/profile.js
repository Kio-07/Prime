module.exports = {
    name: "profile",
    code: `$author[1;$username[$get[u]]'s casino;$authoravatar]
$color[1;$getServerVar[color]]
$description[1;**<:topggDotPink:1061719455853449216> Credits: $numberSeparator[$getUserVar[cash;$get[u]];,] $getServerVar[symbol]
<:topggDotPink:1061719455853449216> Daily streak: $numberSeparator[$getUserVar[dstreak;$get[u]];,]
<:topggDotPink:1061719455853449216> Lootboxes: $numberSeparator[$getUserVar[lootbox;$get[u]];,] 🎁
<:topggDotPink:1061719455853449216> Created On: $getGlobalUserVar[created]**
$onlyIf[$getUserVar[casino;$get[u]]!=unset;{newEmbed:
{description:$getServerVar[error] **| $username You / They don't own a casino.**}
{color:$getvar[color]}}]
$let[u;$findMember[$message[2];yes]]`
}